import type { TypingState } from "@/store/typing.store";

export interface KeyDownResult {
  nextIndex: number;
  typed: string[];
}

const CONTROL_KEYS = new Set([
  "Shift",
  "Control",
  "Alt",
  "Meta",
  "CapsLock",
  "Tab",
  "Escape",
  "ArrowLeft",
  "ArrowRight",
  "ArrowUp",
  "ArrowDown",
  "PageUp",
  "PageDown",
  "Home",
  "End",
  "Insert",
]);

function isPrintableKey(key: string): boolean {
  return key.length === 1 || key === "Enter";
}

function normalizeKey(key: string): string {
  if (key === "Enter") return "\n";
  return key;
}

export function handleKeyDown(
  e: KeyboardEvent,
  state: Pick<TypingState, "text" | "typed" | "currentIndex">
): KeyDownResult | null {
  if (e.ctrlKey || e.metaKey || e.altKey) {
    return null;
  }

  if (CONTROL_KEYS.has(e.key)) {
    return null;
  }

  if (e.key === "Backspace") {
    e.preventDefault();

    if (state.currentIndex === 0) {
      return {
        nextIndex: 0,
        typed: state.typed,
      };
    }

    const typed = [...state.typed];
    typed[state.currentIndex - 1] = "";

    return {
      nextIndex: state.currentIndex - 1,
      typed,
    };
  }

  if (!isPrintableKey(e.key)) {
    return null;
  }

  e.preventDefault();

  if (state.currentIndex >= state.text.length) {
    return {
      nextIndex: state.currentIndex,
      typed: state.typed,
    };
  }

  const typed = [...state.typed];
  typed[state.currentIndex] = normalizeKey(e.key);

  return {
    nextIndex: state.currentIndex + 1,
    typed,
  };
}