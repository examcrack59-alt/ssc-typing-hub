export interface TypingState {
  currentCharacter: number;

  currentWord: number;

  currentLine: number;

  started: boolean;

  finished: boolean;

  paused: boolean;
}